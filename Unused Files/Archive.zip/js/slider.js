$('#slider').slideReveal({
  trigger: $("#trigger")

});
